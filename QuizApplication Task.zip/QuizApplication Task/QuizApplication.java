package Built_in_support;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.Timer;
import java.util.TimerTask;

public class QuizApplication {
    private static ArrayList<QuizQuestion> quizQuestions = new ArrayList<>();
    private static int currentQuestionIndex = 1;
    private static int userScore = 0;
    private static Timer timer;

    public static void main(String[] args) {
        initializeQuiz();

        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Quiz Application!");

        // Iterate through each question
        for (QuizQuestion question : quizQuestions) {
            presentQuestion(question, scanner);
        }

        // Display final results
        displayResults();

        scanner.close();
    }

    private static void initializeQuiz() {
        // Add quiz questions with options and correct answers
        quizQuestions.add(new QuizQuestion("What is the capital of India?",
                new String[]{"A. New Delhi", "B. Banglore", "C. Mumbai", "D. Delhi"}, 1));
        quizQuestions.add(new QuizQuestion("Which planet is known as the Red Planet?",
                new String[]{"A. Venus", "B. Mars", "C. Jupiter", "D. Saturn"}, 2));
        // Add more questions as needed
    }

    private static void presentQuestion(QuizQuestion question, Scanner scanner) {
        System.out.println("\n" + question.question);
        for (String option : question.options) {
            System.out.println(option);
        }

        // Set a timer for 15 seconds for each question
        timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                System.out.println("\nTime's up! Moving to the next question.");
                timer.cancel(); // Cancel the timer to move to the next question
                evaluateAnswer(-1, question.correctOption);
            }
        }, 60000);

        // Get user input for the answer
        System.out.print("\nEnter the number of your answer (1-" + question.options.length + "): ");
        int userAnswer = scanner.nextInt();

        // Cancel the timer as the user has submitted an answer
        timer.cancel();

        // Evaluate the user's answer
        evaluateAnswer(userAnswer, question.correctOption);
    }

    private static void evaluateAnswer(int userAnswer, int correctOption) {
        if (userAnswer == correctOption) {
            System.out.println("Correct!");
            userScore++;
        } else if (userAnswer == -1) {
            System.out.println("Time's up! The correct answer was: " + (char) ('A' + correctOption));
        } else {
            System.out.println("Incorrect! The correct answer was: " + (char) ('A' + correctOption));
        }

        // Move to the next question
        currentQuestionIndex++;
    }

    private static void displayResults() {
        System.out.println("\nQuiz completed! Here are your results:");
        System.out.println("Total Score: " + userScore + " out of " + quizQuestions.size());
    }
}

