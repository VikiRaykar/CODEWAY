package Built_in_support;



class QuizQuestion {
    String question;
    String[] options;
    int correctOption;

    QuizQuestion(String question, String[] options, int correctOption) {
        this.question = question;
        this.options = options;
        this.correctOption = correctOption;
    }
}

